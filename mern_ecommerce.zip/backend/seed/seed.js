import dotenv from "dotenv";
import { connectDB } from "../config/db.js";
import { Product } from "../models/Product.js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();
await connectDB();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dataPath = path.join(__dirname, "products.json");
const products = JSON.parse(fs.readFileSync(dataPath, "utf-8"));

try {
  await Product.deleteMany({});
  const created = await Product.insertMany(products);
  console.log(`Seeded ${created.length} products`);
  process.exit(0);
} catch (err) {
  console.error("Seeding failed:", err);
  process.exit(1);
}