import { useCart } from "../context/CartContext.jsx";
import CartItem from "../components/CartItem.jsx";
export default function Cart() {
  const { items, total, clear } = useCart();
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Your Cart</h2>
      {items.length===0 ? <p className="text-gray-500">Your cart is empty.</p> : (
        <>
          <div>{items.map(i=><CartItem key={i._id} item={i}/>)}</div>
          <div className="mt-6 flex items-center justify-between">
            <div className="text-xl font-semibold">Total: ${total.toFixed(2)}</div>
            <div className="flex gap-2">
              <button className="px-4 py-2 border rounded" onClick={clear}>Clear</button>
              <button className="px-4 py-2 bg-accent text-white rounded" onClick={()=>alert("Checkout not implemented")}>Checkout</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}