import { useEffect, useState } from "react";
import { api } from "../services/api.js";
import ProductCard from "../components/ProductCard.jsx";
export default function Home() {
  const [products, setProducts] = useState([]);
  const [status, setStatus] = useState("idle");
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        setStatus("loading");
        const { data } = await api.get("/products");
        if (alive) { setProducts(data); setStatus("idle"); }
      } catch { setStatus("error"); }
    })();
    return ()=>{alive=false;};
  }, []);
  if (status==="loading") return <div>Loading products...</div>;
  if (status==="error") return <div className="text-red-600">Failed to load products.</div>;
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-4">Products</h2>
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        {products.map(p=><ProductCard key={p._id} product={p}/>)}
      </div>
    </div>
  );
}