import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../services/api.js";
import { useCart } from "../context/CartContext.jsx";
export default function ProductDetails() {
  const { id } = useParams();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(null);
  const [status, setStatus] = useState("idle");
  useEffect(()=>{
    let alive=true;
    (async()=>{
      try{
        setStatus("loading");
        const {data}=await api.get(`/products/${id}`);
        if(alive){setProduct(data); setStatus("idle");}
      } catch{ setStatus("error");}
    })();
    return ()=>{alive=false;};
  },[id]);
  if(status==="loading") return <div>Loading product...</div>;
  if(status==="error") return <div className="text-red-600">Product not found.</div>;
  if(!product) return null;
  return (
    <div className="grid md:grid-cols-2 gap-8">
      <img src={product.image} alt={product.name} className="w-full rounded-lg object-cover"/>
      <div>
        <h1 className="text-3xl font-bold">{product.name}</h1>
        <p className="text-gray-600 mt-2">{product.description}</p>
        <div className="mt-4"><span className="text-2xl font-semibold">${product.price.toFixed(2)}</span></div>
        <p className="mt-2 text-sm text-gray-500">Stock: {product.stock}</p>
        <button className="mt-6 px-4 py-2 bg-primary text-white rounded hover:opacity-90"
         onClick={()=>addToCart({_id:product._id,name:product.name,price:product.price,image:product.image})}>
          Add to Cart
        </button>
      </div>
    </div>
  );
}