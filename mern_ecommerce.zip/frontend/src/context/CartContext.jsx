import { createContext, useContext, useEffect, useMemo, useReducer } from "react";
import toast from "react-hot-toast";
const CartContext = createContext();
const initialState = { items: [] };
function reducer(state, action) {
  switch (action.type) {
    case "INIT": return action.payload;
    case "ADD": {
      const exists = state.items.find(i => i._id === action.item._id);
      const items = exists ? state.items.map(i => i._id===action.item._id?{...i,qty:i.qty+1}:i)
        : [...state.items, { ...action.item, qty: 1 }];
      return { ...state, items };
    }
    case "REMOVE": return { ...state, items: state.items.filter(i => i._id !== action.id) };
    case "DECREMENT": {
      const items = state.items.map(i => i._id===action.id?{...i,qty:i.qty-1}:i).filter(i=>i.qty>0);
      return { ...state, items };
    }
    case "CLEAR": return { items: [] };
    default: return state;
  }}
export function CartProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  useEffect(()=>{ const raw=localStorage.getItem("cart_state"); if(raw) dispatch({type:"INIT",payload:JSON.parse(raw)});},[]);
  useEffect(()=>{ localStorage.setItem("cart_state",JSON.stringify(state));},[state]);
  const total = useMemo(()=>state.items.reduce((s,i)=>s+i.price*i.qty,0),[state.items]);
  const value = {
    items: state.items,
    total,
    addToCart: item => { dispatch({type:"ADD",item}); toast.success("Added to cart");},
    removeFromCart: id => { dispatch({type:"REMOVE",id}); toast("Removed from cart");},
    decrement: id => dispatch({type:"DECREMENT",id}),
    clear: ()=>dispatch({type:"CLEAR"})
  };
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
export const useCart = () => useContext(CartContext);