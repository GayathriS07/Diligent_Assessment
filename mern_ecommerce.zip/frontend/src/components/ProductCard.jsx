import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext.jsx";
export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  return (
    <div className="card rounded-lg overflow-hidden bg-white">
      <Link to={`/products/${product._id}`}>
        <img src={product.image} alt={product.name} className="h-44 w-full object-cover" loading="lazy" />
      </Link>
      <div className="p-4">
        <h3 className="font-semibold text-gray-900">{product.name}</h3>
        <p className="text-sm text-gray-500 line-clamp-2">{product.description}</p>
        <div className="mt-3 flex items-center justify-between">
          <span className="text-lg font-bold">${product.price.toFixed(2)}</span>
          <button onClick={()=>addToCart({_id:product._id,name:product.name,price:product.price,image:product.image})}
            className="px-3 py-2 bg-primary text-white rounded hover:opacity-90">Add to Cart</button>
        </div>
      </div>
    </div>
  );
}