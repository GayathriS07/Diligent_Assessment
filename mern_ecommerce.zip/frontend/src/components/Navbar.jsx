import { Link, NavLink } from "react-router-dom";
import { useCart } from "../context/CartContext.jsx";
export default function Navbar() {
  const { items } = useCart();
  const count = items.reduce((a,b)=>a+b.qty,0);
  const linkClass = ({isActive})=>`px-3 py-2 rounded-md text-sm font-medium ${isActive?"text-white bg-primary":"text-gray-700 hover:text-primary"}`;
  return (
    <header className="sticky top-0 z-20 bg-white/80 backdrop-blur border-b">
      <nav className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link to="/" className="text-xl font-semibold text-gray-900">MERN<span className="text-primary">Shop</span></Link>
        <div className="flex items-center gap-2">
          <NavLink to="/" className={linkClass} end>Home</NavLink>
          <NavLink to="/cart" className={linkClass}>
            Cart
            {count>0 && <span className="ml-2 inline-flex items-center justify-center text-xs bg-accent text-white rounded-full w-5 h-5">{count}</span>}
          </NavLink>
        </div>
      </nav>
    </header>
  );
}