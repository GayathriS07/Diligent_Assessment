import { useCart } from "../context/CartContext.jsx";
export default function CartItem({ item }) {
  const { removeFromCart, addToCart, decrement } = useCart();
  return (
    <div className="flex gap-4 items-center border-b py-4">
      <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded"/>
      <div className="flex-1">
        <h4 className="font-medium">{item.name}</h4>
        <p className="text-sm text-gray-500">${item.price.toFixed(2)}</p>
        <div className="mt-2 flex items-center gap-2">
          <button className="px-2 py-1 border rounded" onClick={()=>decrement(item._id)}>-</button>
          <span className="px-3">{item.qty}</span>
          <button className="px-2 py-1 border rounded" onClick={()=>addToCart(item)}>+</button>
          <button className="ml-4 text-red-600 hover:underline" onClick={()=>removeFromCart(item._id)}>Remove</button>
        </div>
      </div>
      <div className="font-semibold">${(item.price*item.qty).toFixed(2)}</div>
    </div>
  );
}