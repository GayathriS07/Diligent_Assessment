export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: { primary: "#0ea5e9", accent: "#22c55e" }
    }
  },
  plugins: []
};